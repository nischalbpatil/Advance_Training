package Core_java_1_Question;

import java.util.Scanner;

public class Even_Numbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   Scanner scanner=new Scanner(System.in);
   System.out.println("Enter the Number");
   int n=scanner.nextInt();
   
   for(int i=1;i<=n;i++)
   {
	   if(i%2==0)
	   {
		   System.out.println("The Even Number is :"+i);
	   }
   }
	}

}
